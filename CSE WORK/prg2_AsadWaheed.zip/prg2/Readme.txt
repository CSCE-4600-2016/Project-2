/////////////////////////////////////////////////////////////

					README

/////////////////////////////////////////////////////////////


Files: 

	- main.cpp
	- Makefile
Notes: This was originally slated to be an OOP program, but due to serious unforseen
issues with parsing the given file consuming all waking hours from Friday 
afternoon to Saturday night, implementation problems with the header files, 
and non-compatibility with the c++11 format on the linux cse machines, I am 
forced to make this a single-file program with a simple make command to 
compile, and 'make run' to run. For more info on these problems, see the 
main.cpp file block comments.  


